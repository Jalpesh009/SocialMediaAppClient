class Person{
  String username;
  String password;
  String imageurl;
  String description;

  Person(this.username, this.password, this.imageurl, this.description);
}