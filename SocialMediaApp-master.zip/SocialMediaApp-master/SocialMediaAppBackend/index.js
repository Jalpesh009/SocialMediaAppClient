const aws = require('aws-sdk')
require('dotenv').config()
const express = require('express')
const app = express()
const http = require('http').Server(app)
const socket = require('socket.io')(http)
const imageSaver = require('./lib/imageSave')

let config = {
    region: "us-east-1",
    endpoint: "http://dynamodb.us-east-1.amazonaws.com",
    accessKeyId: "AKIAJDEWGNPHLIHOMKXQ",
    secretAccessKey: "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"
}

aws.config = config
let db = new aws.DynamoDB.DocumentClient()

app.use(express.json())
app.use(express.static('assets'))

socket.on('connection', (user) => {
    console.log('user connected')
    let uploadBuffer = [];

    user.on('createuser', (data, callback) => {
        let username = data.username
        let password = data.password

        db.get({
            TableName: 'User', Key: {
                username: username
            }
        }, (err, data) => {
            if (err) {
                console.log('Error has occured while getting data:\n' + err)
                return
            }

            if (data.Item) {
                callback({ success: false, message: "User already exists" })
            }
            else {
                db.put({
                    TableName: 'User', Item: {
                        username: username,
                        password: password,
                        imageurl: 'media/person.jpg',
                        description: 'Edit your profile and add a description!'
                    }
                }, (err, data) => {
                    if (err) {
                        console.log('Error while creating user:\n' + err)
                        callback({ success: false, message: "Error occured while creating user, try again later" })
                        return
                    }

                    callback({ success: true, message: "User is created, you may log-in" })
                })
            }
        })
    })

    user.on('loginuser', (data, callback) => {
        let username = data.username
        let password = data.password

        db.get({
            TableName: 'User', Key: {
                username: username
            }
        }, (err, data) => {
            if (err) {
                console.log('Error has occured while getting data:\n' + err)
                return
            }

            if (data.Item) {
                if (data.Item.password == password)
                    callback({ success: true, message: "Successfully logged-in", username: data.Item.username, password: data.Item.password, imageurl: data.Item.imageurl, description: data.Item.description })
                else
                    callback({ success: false, message: "The password is incorrect" })
            }
            else {
                callback({ success: false, message: "No user with that name found" })
            }
        })
    })

    user.on('upload', (data, callback) => {
        if (data.first == true) {
            uploadBuffer.length = 0;
            console.log("Upload started")
        }

        uploadBuffer = [...uploadBuffer, ...data.bytes];

        if (data.completed) {
            console.log("Upload Completed: Size = " + uploadBuffer.length)
            let path = imageSaver(uploadBuffer, data.extension)
            callback(path)
            uploadBuffer.length = 0;
        }
    })

    user.on('updatedetails', (data, callback) => {
        if (data.imageurl != null) {
            //delete previous image
            db.update({
                TableName: 'User',
                Key: {
                    username: data.username
                },
                UpdateExpression: "set imageurl = :i, description = :d",
                ExpressionAttributeValues: {
                    ":i": data.imageurl,
                    ":d": data.description
                }
            }, (err, data) => {
                if (err)
                    console.log(err)
                else {
                    console.log('profile updated')
                    callback({})
                }
            })
        }
        else {
            db.update({
                TableName: 'User',
                Key: {
                    username: data.username
                },
                UpdateExpression: "set description = :d",
                ExpressionAttributeValues: {
                    ":d": data.description
                }
            }, (err, data) => {
                if (err)
                    console.log(err)
                else {
                    console.log('profile updated')
                    callback({})
                }
            })
        }
    })

    user.on('submitpost', (data, callback) => {
        db.get({
            TableName: 'User', Key: {
                username: data.username
            }
        }, (err, data2) => {
            if (err) {
                console.log('Error has occured while getting data:\n' + err)
                return
            }

            console.log(data.path)

            db.update({
                TableName: 'User',
                Key: {
                    username: data.username
                },
                UpdateExpression: 'set posts = list_append(if_not_exists(posts, :empty_list), :post)',
                ExpressionAttributeValues: {
                    ":post": [data.path],
                    ":empty_list": []
                }
            }, (err, data2) => {
                if (err)
                    console.log(err)
                else {
                    console.log('new post submitted')
                    callback({})
                }
            })
        })
    })
})

http.listen(process.env.PORT || 5000)